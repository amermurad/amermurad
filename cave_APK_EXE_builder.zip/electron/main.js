const { app, BrowserWindow, dialog } = require('electron');
const path = require('path');

async function pick(win, title, items) {
  if (!items.length) return null;
  if (items.length === 1) return items[0];
  const shown = items.slice(0, 8);
  const r = await dialog.showMessageBox(win, {
    type: 'question', title, message: title,
    buttons: [...shown.map(i => i.name), 'إلغاء'], cancelId: shown.length, defaultId: 0
  });
  return r.response < shown.length ? shown[r.response] : null;
}

function createWindow() {
  const win = new BrowserWindow({
    width: 1100, height: 820, backgroundColor: '#101214',
    title: 'منظومة مسح الكهوف — Murad Hasan Alhasheesh',
    autoHideMenuBar: true,
    icon: path.join(__dirname, '..', 'build', 'icon.png'),
    webPreferences: { contextIsolation: true }
  });
  win.loadFile(path.join(__dirname, '..', 'www', 'index.html'));

  const ses = win.webContents.session;
  ses.setPermissionCheckHandler(() => true);
  ses.setPermissionRequestHandler((wc, perm, cb) => cb(true));
  ses.setDevicePermissionHandler(() => true);

  /* بلوتوث: اجمع الأجهزة ثم اعرض قائمة اختيار */
  let timer = null;
  win.webContents.on('select-bluetooth-device', (e, devices, cb) => {
    e.preventDefault();
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const list = devices.map(d => ({ id: d.deviceId, name: d.deviceName || d.deviceId }));
      const c = await pick(win, 'اختر جهاز البلوتوث', list);
      cb(c ? c.id : '');
    }, 2500);
  });

  /* منفذ USB التسلسلي */
  ses.on('select-serial-port', async (e, ports, wc, cb) => {
    e.preventDefault();
    const list = ports.map(p => ({ id: p.portId, name: p.displayName || p.portName }));
    const c = await pick(win, 'اختر منفذ USB', list);
    cb(c ? c.id : '');
  });
}

app.whenReady().then(createWindow);
app.on('window-all-closed', () => app.quit());
